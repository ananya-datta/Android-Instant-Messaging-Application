package com.example.adt.imsimple;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Ananya Datta Treya on 11-11-2015.
 */

public class messageing extends Activity {
    private EditText u1;
    private EditText u2;
    private EditText n;

    String myJSON;
    private static final String TAG_RESULTS = "result";
    public static final String TAG_ID1 = "imeino";
    public static final String TAG_NAME = "name";
    public TextView edit12;

    JSONArray peoples = null;
    ArrayList<HashMap<String, String>> personList;
    ListView list;
    private EditText edit13;
    private TextView edit11;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.messageing);
        String name= getIntent().getStringExtra("abc");
        String name1= getIntent().getStringExtra(listofuser.TAG_ID);
        String name2= getIntent().getStringExtra("abcde");
        edit11 = (TextView) findViewById(R.id.text4);
        edit11.setText(name);
        u1=(EditText) findViewById(R.id.u1);
        u1.setText(name1);
        u2 = (EditText) findViewById(R.id.u2);
        u2.setText(name2);

        list = (ListView) findViewById(R.id.listView);
        personList = new ArrayList<HashMap<String, String>>();

        insertToDatabase1(name,name1,name2);
        getData();
        ArrayAdapter<String>myArrayAdapter;
        //list.setAdapter(myArrayAdapter);
        //list.setAdapter(myArrayAdapter);
        //int index = list.getChildCount();
    }

//pass value
private void insertToDatabase1(String name,String name1,String name2){
    class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String paramUsername = params[0];
            String paramUsername1 = params[1];
            String paramUsername2 = params[2];

            String name = edit11.getText().toString();

            String name1= u1.getText().toString();
            String name2= u2.getText().toString();

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("name", name));
            nameValuePairs.add(new BasicNameValuePair("ida", name1));
            nameValuePairs.add(new BasicNameValuePair("idb", name2));

            try {
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost(
                        "http://insm2015.3eeweb.com/ad3.php");
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpClient.execute(httpPost);

                HttpEntity entity = response.getEntity();


            } catch (ClientProtocolException e) {

            } catch (IOException e) {

            }
            return "";

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

        }
    }
    SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
    sendPostReqAsyncTask.execute(name,name1,name2);
}

    public void getData() {
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {

                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://insm2015.3eeweb.com/addu3.php");
                httppost.setHeader("Content-type", "application/json");
                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();
                    inputStream = entity.getContent();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                } finally {
                    try {
                        if (inputStream != null) inputStream.close();
                    } catch (Exception squish) {
                    }
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }

    protected void showList() {
        try {

            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);
            for (int i = 0; i < peoples.length(); i++) {
                String name1=getIntent().getStringExtra("USER_NAME");
                if(TAG_ID1!=name1) {
                    JSONObject c = peoples.getJSONObject(i);
                    String id = c.getString(TAG_ID1);
                    String name = c.getString(TAG_NAME);
                    HashMap<String, String> persons = new HashMap<String, String>();

                    persons.put(TAG_ID1, id);
                    persons.put(TAG_NAME, name);
                    personList.add(persons);}
            }

            ListAdapter adapter = new SimpleAdapter(
                    messageing.this, personList, R.layout.list_item1,
                    new String[]{TAG_ID1, TAG_NAME},
                    new int[]{R.id.id1, R.id.name}
            );
            list.setAdapter(adapter);
            list.setOnItemClickListener(onListClick);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private AdapterView.OnItemClickListener onListClick = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        }
    };

    public void insert12(View view){
        edit13 = (EditText) findViewById(R.id.editText0);
        String name13 = u1.getText().toString();
        String name14 = u2.getText().toString();
        String add13 = edit13.getText().toString();

        insertToDatabase2(name13,name14,add13);
        String name = edit11.getText().toString();
        String name1= u1.getText().toString();
        String name2= u2.getText().toString();


        insertToDatabase2(name,name1,name2);
        list.deferNotifyDataSetChanged();
        //updateView(index);
        //getData();
    }
    private void insertToDatabase2(String name13,String name14,String add13){
        class SendPostReqAsyncTask1 extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String paramUsername = params[0];
                String paramUsername1 = params[1];
                String paramUsername2 = params[2];

                String name13 = u1.getText().toString();
                String name14 = u2.getText().toString();
                String add13 = edit13.getText().toString();

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("name", name13));
                nameValuePairs.add(new BasicNameValuePair("name1", name14));
                nameValuePairs.add(new BasicNameValuePair("add", add13));


                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(
                            "http://insm2015.3eeweb.com/msg.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "";

            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

            }
        }
        SendPostReqAsyncTask1 sendPostReqAsyncTask1 = new SendPostReqAsyncTask1();
        sendPostReqAsyncTask1.execute(name13,name14,add13);
    }


}







