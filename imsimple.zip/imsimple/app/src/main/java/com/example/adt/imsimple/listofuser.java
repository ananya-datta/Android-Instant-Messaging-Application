package com.example.adt.imsimple;

/**
 * Created by Ananya Datta Treya on 12-11-2015.
 */

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class listofuser extends Activity {
    String myJSON;
    private static final String TAG_RESULTS = "result";
    public static final String TAG_ID = "imeino";
    public static final String TAG_NAME = "name";
    public TextView edit12;
    //private Cursor ourCursor = null;

    JSONArray peoples = null;
    ArrayList<HashMap<String, String>> personList;
    ListView list;

     private EditText edit11;

     public void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.listofuser);
         String name = getIntent().getStringExtra("USER_NAME");
         edit12 = (EditText) findViewById(R.id.username);
         edit12.setText(name);

         list = (ListView) findViewById(R.id.listView);
         personList = new ArrayList<HashMap<String, String>>();

         insertToDatabase1(name);
         getData();
     }

    //start part



    private void insertToDatabase1(String name){
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String paramUsername = params[0];



                String name = edit12.getText().toString();

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("name", name));


                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(
                            "http://insm2015.3eeweb.com/ad2.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "";

            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute(name);
    }



    public void getData() {
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {

                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://insm2015.3eeweb.com/addu1.php");
                httppost.setHeader("Content-type", "application/json");
                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();
                    inputStream = entity.getContent();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                } finally {
                    try {
                        if (inputStream != null) inputStream.close();
                    } catch (Exception squish) {
                    }
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }

    protected void showList() {
        try {

            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);
            for (int i = 0; i < peoples.length(); i++) {
                String name1=getIntent().getStringExtra("USER_NAME");
                if(TAG_ID!=name1) {
                    JSONObject c = peoples.getJSONObject(i);
                    String id = c.getString(TAG_ID);
                    String name = c.getString(TAG_NAME);
                    HashMap<String, String> persons = new HashMap<String, String>();

                    persons.put(TAG_ID, id);
                    persons.put(TAG_NAME, name);
                    personList.add(persons);}
            }

            ListAdapter adapter = new SimpleAdapter(
                    listofuser.this, personList, R.layout.list_item,
                    new String[]{TAG_ID, TAG_NAME},
                    new int[]{R.id.id1, R.id.name}
            );
            list.setAdapter(adapter);
            list.setOnItemClickListener(onListClick);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private AdapterView.OnItemClickListener onListClick = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent i = new Intent(listofuser.this, messageing.class);
            TextView c = (TextView) view.findViewById(R.id.name);
            String p = c.getText().toString();
            TextView cc = (TextView) view.findViewById(R.id.id1);
            String pp = cc.getText().toString();

            String ppp = edit12.getText().toString();
            i.putExtra("abc",p);
            i.putExtra(TAG_ID,pp);
            i.putExtra("abcde",ppp);
            startActivity(i);
        }
    };








    //diff

     public void nxtau(View view){
         Intent intent = new Intent(listofuser.this, adduser.class);
         String name1 = getIntent().getStringExtra("USER_NAME");
         intent.putExtra("USER_NAME",name1);
         finish();
         startActivity(intent);
     }

     //simplyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy


}