package com.example.adt.imsimple;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Ananya Datta Treya on 11-11-2015.
 */

public class message extends Activity {
    private EditText u1;
    private EditText u2;
    private EditText n;
    /*protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message);
        //Bundle extras=getIntent().getExtras();
        String name= getIntent().getStringExtra("abc");
        n = (EditText) findViewById(R.id.text4);
        n.setText(name);
        /*String us1= extras.getString("U");
        String us2= extras.getString("u2");
        n = (EditText) findViewById(R.id.text4);
        n.setText(name);
        u1 = (EditText) findViewById(R.id.u1);
        u1.setText(us1);
        u2 = (EditText) findViewById(R.id.u2);
        u2.setText(us2);*/


    private TextView edit11;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message);
        String name= getIntent().getStringExtra("abc");
        String name1= getIntent().getStringExtra(adduser.TAG_ID);
        String name2= getIntent().getStringExtra("abcde");
        edit11 = (TextView) findViewById(R.id.text4);
        edit11.setText(name);
        u1=(EditText) findViewById(R.id.u1);
        u1.setText(name1);
        u2 = (EditText) findViewById(R.id.u2);
        u2.setText(name2);
        invokeLogin();
    }


    public void invokeLogin(){
        String user2 = edit11.getText().toString();
        String id1=u1.getText().toString();
        String id2=u2.getText().toString();
        login(user2,id1,id2);

    }

    private void login(final String user2,String id1,String id2) {

        class LoginAsync extends AsyncTask<String, Void, String> {
            //private Dialog loadingDialog;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //loadingDialog = ProgressDialog.show(login.this, "Please wait", "Loading...");
            }

            @Override
            protected String doInBackground(String... params) {
                String u2 = params[0];
                String i1 = params[1];
                String i2 = params[2];
                InputStream is = null;
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("username", u2));
                nameValuePairs.add(new BasicNameValuePair("ida", i1));
                nameValuePairs.add(new BasicNameValuePair("idb", i2));
                String result = null;

                try{
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(
                            "http://insm2015.3eeweb.com/request1.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpClient.execute(httpPost);
                    HttpEntity entity = response.getEntity();
                    is = entity.getContent();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result){
                String s = result.trim();
                //loadingDialog.dismiss();
                if(s.equalsIgnoreCase("null")){

                    Button btn=(Button)findViewById(R.id.button3);
                    btn.setVisibility(View.VISIBLE);
                    Button btn1=(Button)findViewById(R.id.button4);
                    btn1.setVisibility(View.INVISIBLE);



                    /*Intent intent = new Intent(message.this, sendreq.class);
                    /*intent.putExtra("USER_NAME", username);
                    finish();
                    startActivity(intent);*/
                }else if(s.equalsIgnoreCase("request")) {

                    Button btn=(Button)findViewById(R.id.button3);
                    btn.setVisibility(View.INVISIBLE);
                    Button btn1=(Button)findViewById(R.id.button4);
                    btn1.setVisibility(View.INVISIBLE);

                    Toast.makeText(getApplicationContext(), "Request is sent", Toast.LENGTH_LONG).show();
                    //startActivity(new Intent(message.this, message.class));
                }
                else if(s.equalsIgnoreCase("pending")) {

                    Button btn=(Button)findViewById(R.id.button3);
                    btn.setVisibility(View.INVISIBLE);
                    Button btn1=(Button)findViewById(R.id.button4);
                    btn1.setVisibility(View.VISIBLE);


                }
                else if(s.equalsIgnoreCase("friend")) {
                    Button btn=(Button)findViewById(R.id.button3);
                    btn.setVisibility(View.INVISIBLE);
                    Button btn1=(Button)findViewById(R.id.button4);
                    btn1.setVisibility(View.INVISIBLE);

                    Toast.makeText(getApplicationContext(), "Already friends", Toast.LENGTH_LONG).show();

                }
            }
        }

        LoginAsync la = new LoginAsync();
        la.execute(user2,id1,id2);

    }

    public void reqq(View view){

        edit11 = (TextView) findViewById(R.id.text4);
        u1=(EditText) findViewById(R.id.u1);
        u2 = (EditText) findViewById(R.id.u2);
        String user2 = edit11.getText().toString();
        String id1=u1.getText().toString();
        String id2=u2.getText().toString();
        insertToDatabase(user2,id1,id2);


        startActivity(new Intent(message.this, login.class));
    }

    private void insertToDatabase(String user2, String id1, String id2){
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String us2 = params[0];
                String i1 = params[1];
                String i2 = params[2];

                String user2 = edit11.getText().toString();
                String id1=u1.getText().toString();
                String id2=u2.getText().toString();

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("username", user2));
                nameValuePairs.add(new BasicNameValuePair("ida", id1));
                nameValuePairs.add(new BasicNameValuePair("idb", id2));

                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(
                            "http://insm2015.3eeweb.com/sendreq.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "";

            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                //Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
                //TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
                //textViewResult.setText("Inserted");
            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute(user2,id1,id2 );
    }


    //ACCEPPPPPPPPPPPPPPPPPPPPPPT

    public void reqq1(View view){

        edit11 = (TextView) findViewById(R.id.text4);
        u1=(EditText) findViewById(R.id.u1);
        u2 = (EditText) findViewById(R.id.u2);
        String user2 = edit11.getText().toString();
        String id1=u1.getText().toString();
        String id2=u2.getText().toString();
        insertToDatabase1(user2,id1,id2);


        startActivity(new Intent(message.this, login.class));
    }

    private void insertToDatabase1(String user2, String id1, String id2){
        class SendPostReqAsyncTask1 extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String us2 = params[0];
                String i1 = params[1];
                String i2 = params[2];

                String user2 = edit11.getText().toString();
                String id1=u1.getText().toString();
                String id2=u2.getText().toString();

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("username", user2));
                nameValuePairs.add(new BasicNameValuePair("ida", id1));
                nameValuePairs.add(new BasicNameValuePair("idb", id2));

                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(
                            "http://insm2015.3eeweb.com/accept.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "";

            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                //Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
                //TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
                //textViewResult.setText("Inserted");
            }
        }
        SendPostReqAsyncTask1 sendPostReqAsyncTask2 = new SendPostReqAsyncTask1();
        sendPostReqAsyncTask2.execute(user2,id1,id2 );
    }





}







